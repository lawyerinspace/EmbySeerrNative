# Seerr Discover — native Emby channel source (v0.1)

This is **a native Emby Server C# plugin source project**, not a Docker application.

## Scope and status

* Browse Seerr trending, popular movies/TV, and upcoming movies/TV within Emby's **channel** system.
* Display descriptions, posters (when the client supports channel images), and a simple available/requested text status.
* **No request submission yet.** Emby's channel API has no supported universal Request button across TV, mobile and web clients. Selecting a title will not submit a request. No phantom video or silent purchase/request is triggered.
* Source project **not compiled or deployed**: this environment has no .NET SDK or copy of your specific Emby Server SDK assemblies. Treat as an SDK integration starter, not an installable tested DLL. Emby versions may require minor API adaptation.

## Build

1. Obtain the Emby plugin-development assemblies for the **same version** of Emby Server installed on your NAS, through the official Emby developer resources. Place `MediaBrowser.Common.dll`, `MediaBrowser.Controller.dll`, `MediaBrowser.Model.dll` inside `lib/`.
2. Install .NET SDK (8 or later is fine as a build host, but targeting `netstandard2.0`).
3. From the `src/` directory run `dotnet restore` and `dotnet build -c Release`.
4. Resolve any API signature differences against your installed Emby version before installing. In particular, the channel media-content enum, image response and plugin constructor may vary.
5. Back up your Emby `/config` directory before manually copying the resulting plugin DLL into the Emby plugins directory inside the mapped `/volume6/Config/Applications/Media Center/Emby` configuration tree. Restart Emby. Verify plugin load and the new channel in the Emby logs. Do not put the DLL in the Docker image's application program folder.

## Configure

The plugin defines these configuration properties:

* `SeerrUrl`: `http://seerr:5055` (correct when both are on the same Compose network)
* `ApiKey`: Seerr API key (must be kept private)
* `PageSize`: `20`

A plugin settings page is not yet included in this prototype. An Emby dashboard configuration page or matching config XML setup is needed before the channel can retrieve Seerr data. **Do not install expecting a ready-to-use user interface.**

## Security

The API key is held server-side, never embedded in channel items. This prototype makes GET calls only. It does not send POST requests or allow clients to request content.

## Roadmap

The next native milestone is server-version-specific compilation and a dashboard settings page. For request submission, a supported client-side action/confirmation mechanism would be needed; Emby's IChannel API alone does not provide a universal cross-client Request button.

References:
* https://github.com/MediaBrowser/Emby/wiki/How-to-build-a-Server-Plugin
* https://dev.emby.media/reference/pluginapi/MediaBrowser.Controller.Channels.IChannel.html
* https://docs.seerr.dev/api/trending-movies-and-tv/
* https://github.com/seerr-team/seerr/blob/develop/seerr-api.yml
